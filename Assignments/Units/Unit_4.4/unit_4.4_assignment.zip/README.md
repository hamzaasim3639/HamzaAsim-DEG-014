An app that doesn't follow the microservice best practices.

To run, use:

```
docker build --tag app_that_doesnt_follow_best_practices .

docker run -p 5000:5000 app_that_doesnt_follow_best_practices
```
