from dataclasses import dataclass #imported package dataclass from dataclasses library 

@dataclass
class Mountain: #initialized a class named 'Mountain'
    name : str   #name of the mountain
    elevation: float  #elevation of the mountain


mountain= Mountain('kay2',2345.56) #instance created of Mountain class 


print(type(mountain)) # prints the data type of the instance

mountain= str(mountain) # converts the object data type to string
print(type(mountain)) # prints the data type after converting to string

    

    

