#!/bin/sh

export MLFLOW_CONDA_HOME=/home/saadsameerkhan/anaconda3/
export MLFLOW_TRACKING_URI="http://0.0.0.0:1593"
export MLFLOW_AR=./mlruns